//
//  AppDelegate.h
//  CustomNews
//
//  Created by hzxsdz0045 on 16/1/15.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

