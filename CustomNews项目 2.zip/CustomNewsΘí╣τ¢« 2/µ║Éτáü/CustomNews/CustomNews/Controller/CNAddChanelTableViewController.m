//
//  CNAddChanelTableViewController.m
//  CustomNews
//
//  Created by 蓦然回首love on 16/1/23.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import "CNAddChanelTableViewController.h"
static NSString* reuseIdentifier = @"cell";
@interface CNAddChanelTableViewController ()<UISearchBarDelegate>
@property   (nonatomic,strong) UISearchBar* searchBar;
@property   (nonatomic,strong) NSMutableArray* resultList;
@end

@implementation CNAddChanelTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    MYLog(@"%@,%ld",self.allNotSelecredChannel,self.allNotSelecredChannel.count);
    self.resultList = [self.allNotSelecredChannel copy];
    self.tableView.tableFooterView = [[UIView alloc]init];
    }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.resultList.count;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return self.searchBar;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier forIndexPath:indexPath];
    CNChannel* channel = self.resultList[indexPath.row];
    cell.textLabel.text = channel.name;
    cell.detailTextLabel.text = channel.channelId;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CNChannel* channel = self.resultList[indexPath.row];
    [self.delegate searchViewController:self withTheSelectedChannel:@[channel]];
    NSMutableArray* tmp = [NSMutableArray arrayWithArray:self.resultList];
    [tmp removeObject:channel];
    self.resultList = tmp;
    [self.tableView reloadData];
}
#pragma mark - UISearchBarDelegate

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    MYLog(@"did change");
    self.resultList = [[self getTheResultArray:searchText] copy];
    [self.tableView reloadData];
}
#pragma mark - 懒加载
- (NSMutableArray *) resultList {
	if(_resultList == nil) {
		_resultList = [NSMutableArray array];

	}
	return _resultList;
}
- (UISearchBar *) searchBar {
	if(_searchBar == nil) {
		_searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, 0, 40)];
        _searchBar.delegate = self;
	}
	return _searchBar;
}
-(NSArray*)getTheResultArray:(NSString*)searchText{
    if(searchText.length == 0){
        return self.allNotSelecredChannel;
    }
    NSMutableArray* resultList = [NSMutableArray array];
    for (CNChannel* channel in self.allNotSelecredChannel) {
        if ([channel.name containsString:searchText] | [channel.channelId containsString:searchText]) {
            [resultList addObject:channel];
        }
    }
    return resultList;
}
@end
