//
//  CNChannelNewsViewController.h
//  CustomNews
//
//  Created by hzxsdz0045 on 16/1/18.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CNChannel.h"
#import "CNNewsReadSituation.h"
@class CNChannelNewsViewController;
@protocol CNChannelNewsViewControllerDelegate <NSObject>

-(void)CNChannelNewsControllerGetTheFirstPic:(NSString*)picUrl;

@end
@interface CNChannelNewsViewController : UIViewController
@property (nonatomic,weak) id<CNChannelNewsViewControllerDelegate> delegate;
@property (nonatomic,strong) CNChannel* channel;//记录当前频道的信息
@property (nonatomic,strong) NSMutableArray* allNews;//记录当前获取的所有的新闻的信息
@property (nonatomic,strong) CNNewsReadSituation* situation;//记录的是该频道所有的新闻的总的数量的信息
@end
