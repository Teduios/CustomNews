//
//  CNDetailNewsController.m
//  CustomNews
//
//  Created by hzxsdz0045 on 16/1/21.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import "CNDetailNewsController.h"
#import <ShareSDK/ShareSDK.h>
#import <ShareSDKUI/ShareSDK+SSUI.h>
#import "MBProgressHUD.h"
#import "TFHpple.h"
#import "TFHppleElement.h"
@interface CNDetailNewsController ()
- (IBAction)shareNews:(UIBarButtonItem *)sender;
@property (weak, nonatomic) IBOutlet UIWebView *newsWebView;
@property (nonatomic,strong) MBProgressHUD* hud;
- (IBAction)goBack:(UIBarButtonItem *)sender;

@end

@implementation CNDetailNewsController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSURL* url = [NSURL URLWithString:self.news.link];
    NSURLRequest* request = [NSURLRequest requestWithURL:url];
    [self.newsWebView loadRequest:request];
    // Do any additional setup after loading the view from its nib.
}
//-(void)parseTheWebData{
//    NSData* data = [NSData dataWithContentsOfURL:[NSURL URLWithString:self.news.link]];
//    TFHpple* parser = [[TFHpple alloc]initWithHTMLData:data];
//    NSArray* dataArray = [parser searchWithXPathQuery:@"//p"];
//    MYLog(@"%@",parser);
//    for (TFHppleElement* element in dataArray) {
//        MYLog(@"++++++++++++%@",element.text);
//    }
//    NSArray* title = [parser searchWithXPathQuery:@"//title"];
//    for (TFHppleElement * atitle in title) {
//        MYLog(@"======%@",atitle.text);
//        MYLog(@"======%@",atitle.raw);
//    }
//    NSArray* images = [parser searchWithXPathQuery:@"//a"];
//    for (TFHppleElement* image in images) {
//        MYLog(@"IIIIIIIIIIIIIIII%@",image.text);
//        MYLog(@"%@",image.raw);
//    }
//}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(MBProgressHUD *)hud{
    if (!_hud) {
        _hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
          // Configure for text only and offset down
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = @"分享中...";
        _hud.margin = 10.f;
        _hud.removeFromSuperViewOnHide = YES;//进程框。
    }
    return _hud;
}

- (IBAction)goBack:(UIBarButtonItem *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
- (IBAction)shareNews:(UIBarButtonItem *)sender {
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"分享" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction* shareToSina = [UIAlertAction actionWithTitle:@"分享到新浪微博" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //新浪分享的代码
        [self shareToSina];
    }];
    [alert addAction:shareToSina];
    [alert addAction:cancelAction];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void)shareToSina{
    NSMutableArray* imageArray = [NSMutableArray array];
    if (self.news.imageurls.count != 0) {
        [imageArray addObject:self.news.imageurls.firstObject[@"url"]];
    }else {
        [imageArray addObject:[UIImage imageNamed:@"3"]];
    }
    //创建分享参数
    NSMutableDictionary *shareParams = [NSMutableDictionary dictionary];
    if (imageArray) {
        [shareParams SSDKSetupShareParamsByText:self.news.title
                                         images:imageArray
                                            url:[NSURL URLWithString:self.news.imageurls.firstObject[@"url"]]
                                          title:@"分享标题"
                                           type:SSDKContentTypeImage];
        
        [shareParams SSDKSetupSinaWeiboShareParamsByText:[NSString  stringWithFormat:@"%@:%@,%@",self.news.channelName,self.news.title,self.news.link]
                                                   title:@"分享标题"
                                                   image:[UIImage imageNamed:@"shareImg.png"]
                                                     url:nil
                                                latitude:0
                                               longitude:0
                                                objectID:nil
                                                    type:SSDKContentTypeImage];

        [ShareSDK showShareEditor:SSDKPlatformTypeSinaWeibo
               otherPlatformTypes:@[@(SSDKPlatformTypeYiXin), @(SSDKPlatformTypeWechat)]
                      shareParams:shareParams
              onShareStateChanged:^(SSDKResponseState state, SSDKPlatformType platformType, NSDictionary *userData, SSDKContentEntity *contentEntity, NSError *error, BOOL end)
         {
             [self showTheShareState:state with:error];
         }];

   }
}
-(void)showTheShareState:(SSDKResponseState)state with:(NSError*)error{
              __weak typeof(self) theController = self;
             switch (state) {
                     
                 case SSDKResponseStateBegin:
                 {
                     self.hud.hidden = NO;
                     break;
                 }
                 case SSDKResponseStateSuccess:
                 {
                     [MBProgressHUD shoWSharing:theController.view withShareInfo:@"分享成功"];
                    
                     break;
                 }
                 case SSDKResponseStateFail:
                 {
                     [MBProgressHUD shoWSharing:theController.view withShareInfo:@"分享失败"];
                     MYLog(@"%@",error.userInfo);
                     break;
                 }
                 case SSDKResponseStateCancel:
                 {
                     [MBProgressHUD shoWSharing:theController.view withShareInfo:@"分享取消"];
                     break;
                 }
                 default:
                     break;
             }
             
             if (state != SSDKResponseStateBegin)
             {
                 
                 [self.hud hide:YES];
             }
}
@end
