//
//  CNDetailNewsController.h
//  CustomNews
//
//  Created by hzxsdz0045 on 16/1/21.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CNNews.h"
@interface CNDetailNewsController : UIViewController
@property (nonatomic,strong) CNNews* news;
@end
