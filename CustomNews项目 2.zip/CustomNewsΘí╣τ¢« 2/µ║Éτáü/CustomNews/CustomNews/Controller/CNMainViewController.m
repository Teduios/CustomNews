//
//  CNMainViewController.m
//  CustomNews
//
//  Created by 蓦然回首love on 16/1/16.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import "CNMainViewController.h"
#import "AFNetworking.h"
#import "CNManager.h"
#import "Masonry.h"
#import "CNMainView.h"
#import "CNAddView.h"
#import "CNNewsReadSituation.h"
#import "CNNews.h"
#import "MBProgressHUD.h"
#import "CNChannelNewsViewController.h"
#import "CNAddChanelTableViewController.h"
#import "CNLoginViewController.h"
#import "CNUserInfo.h"
#import "CNPersonInfViewController.h"
#import "CNXMPPManager.h"
#import "XMPPvCardTemp.h"
#define KDISTANCE 25

@interface CNMainViewController ()<CNChannelNewsViewControllerDelegate,CNAddChannelTableViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *myScolleView;
@property (nonatomic,strong) NSArray* allChannels;
@property (nonatomic,strong) NSMutableArray* allSelectedChannels;
@property (nonatomic,assign) int PortraitNum;
@property (nonatomic,assign) int theTopDis;
@property (nonatomic,assign) int theLeftDis;
@property (nonatomic,assign) int width;
@property (nonatomic,strong) CNMainView* selectedCell;
@property (nonatomic,assign,getter=isLogined) BOOL Logined;
@property  (nonatomic,strong) UIButton* button;
- (IBAction)addChannel:(UIBarButtonItem *)sender;
@end

@implementation CNMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadTheSanboxUserInfo];
    NSFileManager* manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:KChannelPicUrlPathCenters]) {
        NSError* error = nil;
        [manager createDirectoryAtPath:KChannelPicUrlPathCenters withIntermediateDirectories:YES attributes:nil error:&error];
    }
    CGFloat width = [[UIScreen mainScreen] bounds].size.width;
    CGFloat heigth = [[UIScreen mainScreen] bounds].size.height;
    if (heigth > width) {
        [self setVerticalAttribute];
    }else{
        [self setLandScapeAttribute];
    }
       [self setInterFace];
    [self getTheAllChannels];
    self.view.userInteractionEnabled = YES;
    self.myScolleView.userInteractionEnabled = YES;
    self.myScolleView.bounces = NO;
    self.myScolleView.pagingEnabled = YES;
    self.width = (self.view.bounds.size.width - 2 * self.theLeftDis) / self.PortraitNum;
    
    [self setNavLeftItem];
    
   
    // Do any additional setp after loading the view.
}
-(void)loadTheSanboxUserInfo{
    [[CNUserInfo sharedCNUserInfo] loadUserInfoFromSandBOX];
    if ([CNUserInfo sharedCNUserInfo].userName.length != 0) {
        [[CNXMPPManager sharedCNXMPPManager] login:^(CNXMPPResultType resultType) {
            [self loginType:resultType];
        }];
    }else{
        self.Logined = NO;
    }
}
-(void)loginType:(CNXMPPResultType)type{
    switch (type) {
        case CNXMMPPResultTypeNetError:
        case CNXMPPResultTypeLoginFailed:
            [MBProgressHUD showResultInfo:@"登录失败" InView:self.view];
            break;
            case CNXMPPResultTypeLoginSuccess:
            MYLog(@"登录成功");
            [self loginSucess];
            break;
        default:
            break;
    }
}//检测以往登录记录 并登录
-(void)setNavLeftItem{
    self.button = [UIButton buttonWithType:UIButtonTypeCustom];
    self.button.frame = CGRectMake(0, 0, 40, 40);
    self.button.layer.cornerRadius = 20;
    [self.button setTitle:@"Login" forState:UIControlStateNormal];
    self.button.titleLabel.font = [UIFont systemFontOfSize:12];
    self.button.layer.masksToBounds = YES;
    self.button.backgroundColor = [UIColor redColor];
    [self.button addTarget:self action:@selector(showTheUserInfo:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:self.button];
}
-(void)showTheUserInfo:(UIButton*)button{
    if (self.isLogined) {
        CNPersonInfViewController* personalInfo = [[CNPersonInfViewController alloc]init];
        [self.navigationController pushViewController:personalInfo animated:YES];
    }else{
       CNLoginViewController* loginVC = [[CNLoginViewController alloc]init];
       [self.navigationController pushViewController:loginVC animated:YES];
    }
}
-(NSArray*)getTheAllChannels{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    AFHTTPSessionManager* manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    __block   NSMutableArray* array = [NSMutableArray array];
    [manager.requestSerializer setValue:APPKey forHTTPHeaderField:@"apikey"];
    MBProgressHUD* hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.labelText = @"Loading";
    [manager GET:kUrlAllChannelInf parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        MYLog(@"%@",responseObject);
        [hud hide:YES];
        self.allChannels = (NSMutableArray*)[CNManager parseTheChannelDataByJSONDic:responseObject];
        NSRange range;
        range.location = 0;
        range.length = 9;
        MYLog(@"%ld",array.count);
        NSString* channelPath = [kChannelPicUrlPathCenter stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",[CNUserInfo sharedCNUserInfo].userName]];
        if (self.isLogined && [[NSFileManager defaultManager]fileExistsAtPath:channelPath]) {
            NSData* data = [NSData dataWithContentsOfFile:channelPath];
            NSKeyedUnarchiver* unArchiver = [[NSKeyedUnarchiver alloc]initForReadingWithData:data];
            self.allSelectedChannels = [unArchiver decodeObjectForKey:[CNUserInfo sharedCNUserInfo].userName];
            [unArchiver finishDecoding];
        }else{
        self.allSelectedChannels = [[self.allChannels subarrayWithRange:range] mutableCopy];
        }
        [self setInterFace];
        [[UIApplication sharedApplication]setNetworkActivityIndicatorVisible:NO];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        MYLog(@"error%@",error.userInfo);
        [hud hide:YES];
        [MBProgressHUD showConnectFailed:self.view];
        [[UIApplication sharedApplication]setNetworkActivityIndicatorVisible:NO];
    }];
    return array;
}

-(void)setAllSelectedChannels:(NSMutableArray *)allSelectedChannels{
    _allSelectedChannels = allSelectedChannels;
    [self setInterFace];
}
//通过该方法设置主界面
-(void)setInterFace{
    NSArray* allViews = [self.myScolleView subviews];
    for (UIView* vc in allViews) {
        [vc removeFromSuperview];
    }
    int count = 0;//总得cell 的数量
    if (self.allChannels.count == 0) {
        count = 10;
    }else {
        count = (int)self.allSelectedChannels.count + 1;
    }
    UIView* lastView = nil;
    for (int i = 0; i <= (count - 1)/12; i ++) {//第一层循环
        UIView* theView = [[UIView alloc]init];
        [self.myScolleView addSubview:theView];
        theView.backgroundColor = [UIColor   redColor];
        [theView mas_makeConstraints:^(MASConstraintMaker *make) {
            if (i == 0) {
                make.left.top.bottom.mas_equalTo(0);
            }else{
                make.left.mas_equalTo(lastView.mas_right).mas_equalTo(0);
                make.top.bottom.mas_equalTo(self.myScolleView);
                make.size.mas_equalTo(lastView);
                if (i == count/12) {
                    make.right.mas_equalTo(0);
                }
                                        }
        }];
       
        int secCount = 0;//设置每个界面的cell。
        NSMutableArray* theChannel = [NSMutableArray array];
        if (i < (count - 1)/12) {
            NSRange theRange ;
            theRange.location = i * 12;
            theRange.length = 12;
            theChannel = (NSMutableArray*)[self.allSelectedChannels subarrayWithRange:theRange];

        }
        else {
            NSRange theRange ;
            theRange.location = i * 12;
            theRange.length = count - i * 12 - 1 ;
            theChannel = (NSMutableArray*)[self.allSelectedChannels subarrayWithRange:theRange];

        }
        if (i < count/12) {
            secCount = 12;
        }else{
            secCount = count - i * 12;
        }
            __block UIView* theLastLineCell = nil;
            __block UIView* theLastCell = nil;
            for (int n = 0; n < secCount; n++) {//第二层循环
                UIView* mainCell = nil;
                if (count == (i * 12 + n + 1)) {
                mainCell = [[CNAddView alloc]init];
                    mainCell.backgroundColor   = [UIColor orangeColor];
            }else{
                mainCell = [CNMainView CreateMainView];
                ((CNMainView*)mainCell).channel = theChannel[n];
                
            }
            [theView addSubview:mainCell];
            [mainCell mas_makeConstraints:^(MASConstraintMaker *make) {
                if (n == 0) {
                    make.left.mas_equalTo(self.theLeftDis);
                    make.top.mas_equalTo(self.theTopDis);
                    make.size.mas_equalTo(CGSizeMake(self.width, self.width*0.83));
                    theLastCell = mainCell;
                    theLastLineCell = mainCell;
                }else {
                    if (n % self.PortraitNum == 0) {
                        make.left.mas_equalTo(self.theLeftDis);
                        make.top.mas_equalTo(theLastLineCell.mas_bottom);
                        make.size.mas_equalTo(theLastCell);
                        theLastLineCell = mainCell;
                    }else{
                    make.left.mas_equalTo(theLastCell.mas_right);
                    make.centerY.mas_equalTo(theLastCell);
                    make.size.mas_equalTo(theLastCell);
                    }
                    if (n % self.PortraitNum == self.PortraitNum - 1) {
                        make.right.mas_equalTo(-self.theLeftDis);
                    }
                    theLastCell = mainCell;
                }
                
             
            }];
            if (i == (count - 1) /12 && n == secCount - 1) {
                UIButton* addButton = [UIButton buttonWithType:UIButtonTypeCustom];
                [self.myScolleView addSubview:addButton];
                [addButton mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.edges.mas_equalTo(mainCell);
                }];
                [addButton addTarget:self action:@selector(addAChannel:) forControlEvents:UIControlEventTouchUpInside];
            }else {
                UIButton* button = [UIButton buttonWithType:UIButtonTypeCustom];
                button.tag = i * 12 + n;
                [self.myScolleView addSubview:button];
                [button mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.right.bottom.top.mas_equalTo(mainCell);
                }];
                __weak typeof(self) theViewController = self;
                [button bk_addEventHandler:^(UIButton* sender) {
                    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"警告" message:@"您准备删除一个新闻频道" preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction* conformAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
                        int theTag = (int)sender.tag;
                        CNChannel* theChooseChannel = self.allSelectedChannels[theTag];
                        [theViewController.allSelectedChannels removeObject:theChooseChannel];
                        [theViewController setInterFace];
                        [self saveTheAllSelectedChannelToSandBox];
                    }];
                    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
                    [alert addAction:conformAction];
                    [alert addAction:cancelAction];
                    [theViewController presentViewController:alert animated:YES completion:nil];
                } forControlEvents:UIControlEventTouchDragInside];
                [button bk_addEventHandler:^(UIButton* sender) {
                    int theTag = (int)sender.tag;
                    CNChannel* theChooseChannel = self.allSelectedChannels[theTag];
                    self.selectedCell = (CNMainView*)mainCell;
                    [self chooseTheNewsButton:theChooseChannel];
                } forControlEvents:UIControlEventTouchUpInside];
            }
        }
        lastView  = theView;
        }
}
-(void)chooseTheNewsButton:(CNChannel*)channel{
    [self getTheSelectedChannelNews:channel];
    
}//选择某个城市
-(void)addAChannel:(UIButton*)button{
    MYLog(@"add");
    [self performSegueWithIdentifier:@"toAddTableViewController" sender:[self getTheNotSelectedArray]];
}

/**
 *  获得未被选中的频道信息
 *
 *  @return 数组
 */
-(NSArray*)getTheNotSelectedArray{
    NSMutableArray* notSelectedChannel = [NSMutableArray array];
    for (CNChannel* channel in self.allChannels) {
        if (![self.allSelectedChannels containsObject:channel]) {
            [notSelectedChannel  addObject:channel];
        }
    }
    return notSelectedChannel;
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    CNAddChanelTableViewController* addViewController  = segue.destinationViewController;
    addViewController.delegate = self;
    addViewController.allNotSelecredChannel = (NSArray*)sender;
    
}
#pragma mark - 解析某个频道的新闻
-(void)getTheSelectedChannelNews:(CNChannel*)channel{
    AFHTTPSessionManager* manager = [AFHTTPSessionManager manager];
    [manager.requestSerializer setValue:APPKey forHTTPHeaderField:@"apikey"];
    NSMutableDictionary* parameters = [NSMutableDictionary dictionary];
    parameters[@"channelId"] = channel.channelId;
    MBProgressHUD* hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.labelText = @"Loading";
    [manager GET:kUrlTheChannelSearchNews parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        CNNewsReadSituation* newsSituation = [CNManager parseTheNewsReadSituationByDic:responseObject];
        NSArray* allChannelNews = [CNManager parseTheNewsByDic:responseObject];
        CNChannelNewsViewController* newsController = [[CNChannelNewsViewController alloc]init];
        newsController.situation = newsSituation;
        newsController.allNews = [allChannelNews mutableCopy];
        newsController.channel = channel;
        newsController.delegate = self;
        [self presentViewController:newsController animated:YES completion:nil];
        [hud hide:YES];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        MYLog(@"%@",error.userInfo);
        [hud  hide:YES];
        [MBProgressHUD showConnectFailed:self.view];
    }];
    
}
#pragma mark -CNChannelNewsViewControllerDelegate 
-(void)CNChannelNewsControllerGetTheFirstPic:(NSString *)picUrl{
    MYLog(@"%@",kChannelPicUrlPathCenter);
    NSString* filePath  = [KChannelPicUrlPathCenters stringByAppendingPathComponent:self.selectedCell.channel.channelId];
    NSError* error = nil;
    if ([[NSFileManager defaultManager]fileExistsAtPath:filePath]) {
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:&error];
        if (error) {
            MYLog(@"remove error%@",error.userInfo);
        }
           }
    error = nil;
    NSDictionary* dic = [NSDictionary dictionaryWithObject:picUrl forKey:self.selectedCell.channel.channelId];
    [dic writeToFile:filePath atomically:NO];
    if (error) {
           MYLog(@"%@",error.userInfo);
        }
    self.selectedCell.picUrl = picUrl;
}
-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
  
    switch (toInterfaceOrientation) {
        case UIInterfaceOrientationPortrait:
            [self setVerticalAttribute];
            break;
        case UIInterfaceOrientationLandscapeLeft:
            [self setLandScapeAttribute];
            break;
        case UIInterfaceOrientationLandscapeRight:
            [self setLandScapeAttribute];
            break;
        case  UIInterfaceOrientationPortraitUpsideDown:
            [self setVerticalAttribute];
            break;
        default:
            break;
    }
    self.width = (self.view.bounds.size.width - 2 * self.theLeftDis) / self.PortraitNum;
    [self setInterFace];
}
-(void)setVerticalAttribute{
    self.PortraitNum = 3;
    self.theTopDis = 2 * KDISTANCE;
    self.theLeftDis = KDISTANCE;
}
-(void)setLandScapeAttribute{
    self.theTopDis = KDISTANCE;
    self.theLeftDis = 4 * KDISTANCE;
    self.PortraitNum = 4;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - CNAddChannelTableViewControllerDelegate
-(void)searchViewController:(CNAddChanelTableViewController *)addVC withTheSelectedChannel:(NSArray *)selChannel{
    for (CNChannel* channel in selChannel) {
        [self.allSelectedChannels addObject:channel];
    }
    [self saveTheAllSelectedChannelToSandBox];
    
    [self setInterFace];
}

- (IBAction)addChannel:(UIBarButtonItem *)sender {
    [self addAChannel:nil];                                                                                                                                                                               
}
#pragma -mark 登录成功后
-(void)loginSucess{
    [self.button setTitle:[CNUserInfo sharedCNUserInfo].userName forState:UIControlStateNormal];
    XMPPvCardTemp* tmp = [[CNXMPPManager sharedCNXMPPManager].xmppVCard myvCardTemp];
    [self.button setTitle:nil forState:UIControlStateNormal];
    if (tmp.photo.length == 0) {
        MYLog(@"头像是空的爱main");
        [self.button setTitle:[CNUserInfo sharedCNUserInfo].userName forState:UIControlStateNormal];
         }else{
             [self.button setBackgroundImage:[UIImage imageWithData:tmp.photo] forState:UIControlStateNormal];
         }
    [[CNUserInfo sharedCNUserInfo]saveUserInfoToSandBox];
    self.Logined = YES;
}
-(void)loginOut{
    self.Logined = NO;
    [self.button setTitle:@"Login" forState:UIControlStateNormal];
    [self.button setBackgroundImage:nil forState:UIControlStateNormal];
}
#pragma mark - 当选中的频道有变化，且用户登录中 ，则将频道信息缓存到本地
-(void)saveTheAllSelectedChannelToSandBox{
    NSError* error = nil;
    if (self.isLogined) {
        NSString *str = [NSString stringWithFormat:@"%@",[CNUserInfo sharedCNUserInfo].userName];
        NSString* channelSavePath = [kChannelPicUrlPathCenter stringByAppendingPathComponent:str];
        if ([[NSFileManager defaultManager] fileExistsAtPath:channelSavePath]) {
            [[NSFileManager defaultManager]removeItemAtPath:channelSavePath error:&error];
            if (error) {
                MYLog(@"%@",error.userInfo);
            }
        }
        NSMutableData* mutableData = [NSMutableData data];
        NSKeyedArchiver* archiver = [[NSKeyedArchiver alloc]initForWritingWithMutableData:mutableData];
        [archiver encodeObject:self.allSelectedChannels forKey:[CNUserInfo sharedCNUserInfo].userName];
        [archiver finishEncoding];
        [mutableData writeToFile:channelSavePath atomically:YES];
    }
}
@end
