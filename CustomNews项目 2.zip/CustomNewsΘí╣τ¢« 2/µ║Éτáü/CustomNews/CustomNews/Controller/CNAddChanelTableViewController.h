//
//  CNAddChanelTableViewController.h
//  CustomNews
//
//  Created by 蓦然回首love on 16/1/23.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CNChannel.h"
@class CNAddChanelTableViewController;
@protocol CNAddChannelTableViewControllerDelegate <NSObject>

-(void)searchViewController:(CNAddChanelTableViewController*)addVC withTheSelectedChannel:(NSArray*)selChannel;

@end
@interface CNAddChanelTableViewController : UITableViewController
@property  (nonatomic,strong) NSArray* allNotSelecredChannel;
@property   (nonatomic,weak) id<CNAddChannelTableViewControllerDelegate> delegate;
@end
