//
//  CNMainViewController.h
//  CustomNews
//
//  Created by 蓦然回首love on 16/1/16.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CNMainViewController : UIViewController
-(void)loginSucess;
-(void)loginOut;
@end
