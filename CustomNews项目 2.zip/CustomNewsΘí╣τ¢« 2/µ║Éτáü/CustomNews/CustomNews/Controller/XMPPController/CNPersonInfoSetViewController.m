//
//  CNPersonInfoSetViewController.m
//  CustomNews
//
//  Created by hzxsdz0045 on 16/1/26.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import "CNPersonInfoSetViewController.h"
#import "MBProgressHUD.h"
#import "CNXMPPManager.h"
#import "CNUserInfo.h"
@interface CNPersonInfoSetViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
@property (weak, nonatomic) IBOutlet UITextField *nickName;
@property (weak, nonatomic) IBOutlet UITextField *emailAdress;

- (IBAction)finishedSet:(UIButton *)sender;
@end

@implementation CNPersonInfoSetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.tmpVCard.photo.length == 0) {
        MYLog(@"头像是空的爱");
        self.headImageView.image = [UIImage imageNamed:@"default"];
    }else{
        self.headImageView.image = [UIImage imageWithData:self.tmpVCard.photo];
    }
    self.headImageView.layer.cornerRadius = self.headImageView.bounds.size.width * 0.5;
    self.headImageView.layer.masksToBounds = YES;
    self.headImageView.userInteractionEnabled = YES;
    UITapGestureRecognizer* tapGes = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(choosePhoto)];
    [self.headImageView addGestureRecognizer:tapGes];
    self.nickName.text = self.tmpVCard.nickname;
    self.emailAdress.text = self.tmpVCard.mailer;
    // Do any additional setup after loading the view from its nib.
}
-(void)choosePhoto{
     UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"请选择" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction* camera = [UIAlertAction actionWithTitle:@"相机" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            UIImagePickerController* pickerController = [[UIImagePickerController alloc]init];
            pickerController.delegate = self;
            pickerController.sourceType = UIImagePickerControllerCameraCaptureModeVideo;
            pickerController.allowsEditing = YES;
            [self presentViewController:pickerController animated:YES completion:nil];
        }
    }];
    UIAlertAction* cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction* photos = [UIAlertAction actionWithTitle:@"相册" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        UIImagePickerController* pickerContoller = [[UIImagePickerController alloc]init];
        pickerContoller.delegate = self;
        pickerContoller.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        pickerContoller.allowsEditing = YES;
        [self presentViewController:pickerContoller animated:YES completion:nil];
    }];
    [alert addAction:camera];
    [alert addAction:cancel];
    [alert addAction:photos];
    [self presentViewController:alert animated:YES completion:nil];
}
#pragma -mark UIImagePickerControllerDelegate
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    UIImage* image = info[UIImagePickerControllerEditedImage];
    self.headImageView.image = image;
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)finishedSet:(UIButton *)sender {
    if (self.nickName.text.length == 0) {
        [MBProgressHUD showResultInfo:@"昵称不能为空" InView:self.view];
    }else{
        self.tmpVCard.nickname = self.nickName.text;
        self.tmpVCard.mailer = self.emailAdress.text;
        self.tmpVCard.photo = UIImageJPEGRepresentation(self.headImageView.image, 0.5f);
        [[CNXMPPManager sharedCNXMPPManager].xmppVCard updateMyvCardTemp:self.tmpVCard];
        [[CNUserInfo sharedCNUserInfo]saveUserInfoToSandBox];
        [self.navigationController popViewControllerAnimated:YES];
    }
}
@end
