//
//  CNLoginViewController.m
//  CustomNews
//
//  Created by hzxsdz0045 on 16/1/25.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import "CNLoginViewController.h"
#import "CNRegisterViewController.h"
#import "CNUserInfo.h"
#import "CNXMPPManager.h"
#import "MBProgressHUD.h"
#import "CNMainViewController.h"
@interface CNLoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userName;
@property (weak, nonatomic) IBOutlet UITextField *userPassWord;
@property (weak, nonatomic) IBOutlet UIImageView *backGroundImageIView;
@property (weak, nonatomic) IBOutlet UIImageView *inputBackGround;

- (IBAction)RegisterButton:(UIButton *)sender;
- (IBAction)LoginButton:(UIButton *)sender;
@end

@implementation CNLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.inputBackGround.layer.cornerRadius = 5;
    self.inputBackGround.layer.masksToBounds = YES;
    CGFloat height = [UIScreen mainScreen].bounds.size.height;
    CGFloat width = [[UIScreen mainScreen] bounds].size.width;
    if (height > width) {
        self.backGroundImageIView.image = [UIImage imageNamed:@"背景图片.png"];
    }else{
        self.backGroundImageIView.image = [UIImage imageNamed:@"背景图片L.png"];
    }
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    UIImageView* imageName = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"icon"]];
    imageName.frame = CGRectMake(0, 0, 55, 20);
    imageName.contentMode = UIViewContentModeCenter;
    self.userName.leftViewMode = UITextFieldViewModeAlways;
    self.userName.leftView = imageName;
    
    UIImageView* imagePassWord = [[UIImageView  alloc]initWithImage:[UIImage imageNamed:@"lock"]];
    imagePassWord.frame = CGRectMake(0, 0, 55, 20);
    imagePassWord.contentMode = UIViewContentModeCenter;
    self.userPassWord.leftViewMode = UITextFieldViewModeAlways;
    self.userPassWord.leftView = imagePassWord;
}
- (IBAction)RegisterButton:(UIButton *)sender {
    CNRegisterViewController* registerViewC = [[CNRegisterViewController alloc]init];
    [self.navigationController pushViewController:registerViewC animated:YES];
}

- (IBAction)LoginButton:(UIButton *)sender {
    if (self.userName.text.length == 0 | self.userPassWord.text.length == 0) {
        [self setAleryViewWithString:@"用户名或密码不能为空,请重新输入!"];
    }else{
        CNUserInfo* userInfo = [CNUserInfo sharedCNUserInfo];
        userInfo.registerType = NO;
        userInfo.userName = self.userName.text;
        userInfo.userPwd = self.userPassWord.text;
        __weak typeof(self) weakViewController = self;
        MBProgressHUD* hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.mode = MBProgressHUDModeAnnularDeterminate;
        hud.removeFromSuperViewOnHide = YES;
        hud.labelText = @"Login...";
        [[CNXMPPManager sharedCNXMPPManager] login:^(CNXMPPResultType resultType) {
            [hud hide:YES];
            [weakViewController loginResultHandle:resultType];
        }];
    }
}
-(void)loginResultHandle:(CNXMPPResultType)type{
    switch (type) {
        case CNXMMPPResultTypeNetError:
            [self setAleryViewWithString:@"网络连接失败，请稍后再试！"];
            break;
        case CNXMPPResultTypeLoginFailed:
            [self setAleryViewWithString:@"用户名或密码错误，请重新输入"];
            break;
        case CNXMPPResultTypeLoginSuccess:
            MYLog(@"登录成功");
            [self.navigationController popViewControllerAnimated:YES];
            if ([self.navigationController.viewControllers.firstObject isMemberOfClass:[CNMainViewController class]]) {
                CNMainViewController* mainVC = self.navigationController.viewControllers.firstObject;
                [mainVC loginSucess];
            }
            break;
        default:
            break;
    }
}
-(void)setAleryViewWithString:(NSString*)str{
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"警告！" message:str preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction* cancel = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil];
    [alert addAction:cancel];
    [self presentViewController:alert animated:YES completion:nil];
}
@end
