//
//  CNPersonInfViewController.m
//  CustomNews
//
//  Created by hzxsdz0045 on 16/1/26.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import "CNPersonInfViewController.h"
#import "CNPersonInfoSetViewController.h"
#import "CNUserInfo.h"
#import "CNXMPPManager.h"
#import "XMPPvCardTemp.h"
#import "CNMainViewController.h"
@interface CNPersonInfViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *headImage;
@property (weak, nonatomic) IBOutlet UILabel *nickName;
@property (weak, nonatomic) IBOutlet UILabel *acount;
@property (nonatomic,strong) XMPPvCardTemp* tmp;
- (IBAction)personalInfoSet:(UIButton *)sender;
- (IBAction)loginOut:(UIButton *)sender;

@end

@implementation CNPersonInfViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    CNUserInfo* userInfo = [CNUserInfo sharedCNUserInfo];
    XMPPvCardTemp* xmppTmp = [[CNXMPPManager sharedCNXMPPManager].xmppVCard myvCardTemp];
    self.nickName.text = xmppTmp.nickname.length == 0 ?userInfo.userName:xmppTmp.nickname;
    if (xmppTmp.photo.length) {
        self.headImage.image = [UIImage imageWithData:xmppTmp.photo];
    }else{
        self.headImage.image = [UIImage imageNamed:@"defaultHeadImage.png"];
        }
    self.headImage.layer.cornerRadius = self.headImage.bounds.size.width * 0.5;
    self.headImage.layer.masksToBounds = YES;
    self.acount.text = [NSString stringWithFormat:@"%@@%@",[CNUserInfo sharedCNUserInfo].userName,CNXMPPDOMAIN];
    self.tmp = xmppTmp;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)personalInfoSet:(UIButton *)sender {
    CNPersonInfoSetViewController* setVC = [[CNPersonInfoSetViewController alloc]init];
    setVC.tmpVCard = self.tmp;
    [self.navigationController pushViewController:setVC animated:YES];
}

- (IBAction)loginOut:(UIButton *)sender {
    [[CNUserInfo sharedCNUserInfo]deleteUserInfoFromSanBox];
    [[CNXMPPManager sharedCNXMPPManager] sendOffLine];
    CNMainViewController* main = self.navigationController.viewControllers.firstObject;
    if ([main isMemberOfClass:[CNMainViewController class]]) {
        [main loginOut];
       [self.navigationController popViewControllerAnimated:YES];
    }
   
}
@end
