//
//  CNRegisterViewController.m
//  CustomNews
//
//  Created by hzxsdz0045 on 16/1/26.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import "CNRegisterViewController.h"
#import "CNUserInfo.h"
#import "CNXMPPManager.h"
#import "MBProgressHUD.h"
@interface CNRegisterViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userName;
@property (weak, nonatomic) IBOutlet UITextField *userPassWord;
@property (weak, nonatomic) IBOutlet UIImageView *backGroundImageView;
@property (weak, nonatomic) IBOutlet UIImageView *inputBackGround;

- (IBAction)register:(UIButton *)sender;
@end

@implementation CNRegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.inputBackGround.layer.cornerRadius = 5;
    self.inputBackGround.layer.masksToBounds = YES;
    CGFloat height = [UIScreen mainScreen].bounds.size.height;
    CGFloat width = [[UIScreen mainScreen] bounds].size.width;
    if (height > width) {
        self.backGroundImageView.image = [UIImage imageNamed:@"背景图片.png"];
    }else{
        self.backGroundImageView.image = [UIImage imageNamed:@"背景图片L.png"];
    }

    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    UIImageView* imageName = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"icon"]];
    imageName.frame = CGRectMake(0, 0, 55, 20);
    imageName.contentMode = UIViewContentModeCenter;
    self.userName.leftViewMode = UITextFieldViewModeAlways;
    self.userName.leftView = imageName;
    
    UIImageView* imagePassWord = [[UIImageView  alloc]initWithImage:[UIImage imageNamed:@"lock"]];
    imagePassWord.frame = CGRectMake(0, 0, 55, 20);
    imagePassWord.contentMode = UIViewContentModeCenter;
    self.userPassWord.leftViewMode = UITextFieldViewModeAlways;
    self.userPassWord.leftView = imagePassWord;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)register:(UIButton *)sender {
    if (self.userPassWord.text.length == 0 | self.userName.text.length == 0){
        [MBProgressHUD showResultInfo:@"用户名或密码不能为空" InView:self.view];
    }else{
        CNUserInfo* userInfo = [CNUserInfo sharedCNUserInfo];
        userInfo.registerName = self.userName.text;
        userInfo.registerPasswd = self.userPassWord.text;
        userInfo.registerType = YES;
        __weak typeof(self) theViewController = self;
        [[CNXMPPManager sharedCNXMPPManager] registerUser:^(CNXMPPResultType resultType) {
            [theViewController registerDidCompletedWith:resultType];
        }];
    }
}
-(void)registerDidCompletedWith:(CNXMPPResultType)type{
    switch (type) {
        case CNXMMPPResultTypeNetError:
            [MBProgressHUD showResultInfo:@"网络连接失败，请稍后再试" InView:self.view];
            break;
        case CNXMMPPResultTypeRegisterFailed:
            [MBProgressHUD showResultInfo:@"注册失败，请更换用户名再试" InView:self.view];
            break;
        case CNXMMPPResultTypeRegisterSuccess:
            MYLog(@"注册成功");
            [MBProgressHUD showResultInfo:@"注册成功" InView:self.view];
            [self.navigationController popViewControllerAnimated:YES];
            break;
        default:
            break;
    }
}
@end
