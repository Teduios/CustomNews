//
//  CNPersonInfViewController.h
//  CustomNews
//
//  Created by hzxsdz0045 on 16/1/26.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CNPersonInfViewController : UIViewController

@end
