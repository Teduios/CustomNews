//
//  CNChannelNewsViewController.m
//  CustomNews
//
//  Created by hzxsdz0045 on 16/1/18.
//  Copyright © 2016年 SSF. All rights reserved.
//

#import "CNChannelNewsViewController.h"
#import "Masonry.h"
#import "CNChannelNews.h"
#import "CNNews.h"
#import "AFNetworking.h"
#import "CNManager.h"
#import "MBProgressHUD.h"
#import "CNDetailNewsController.h"
@interface CNChannelNewsViewController ()
@property (nonatomic,assign) NSInteger index;//记录当前加载新闻的总得条数
@property (nonatomic,strong) CNChannelNews* channelNews;
@property  (nonatomic,assign,getter=isFirst) BOOL getThePic;
@end

@implementation CNChannelNewsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.getThePic = NO;
    if (self.allNews.count > 6) {
        self.index = 6;
    }else {
        self.index = self.allNews.count;
    }
    self.view.backgroundColor = [UIColor whiteColor];
    [self setInterChannelNameLabel];
    self.channelNews = [self setChannelNews];
    [self.view addSubview:self.channelNews];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getTheDetailNews:) name:KNEWSBUTTONCLICK object:nil];
    [self  setSwipeGes];//设置手势，翻看下一页的新闻，返回，翻看上一页新闻
    [self    getTheChannelShowPic];
    // Do any additional setup after loading the view from its nib.
}
-(void)getTheChannelShowPic{
    for (CNNews* picNews in self.allNews) {
        if (picNews.imageurls.count!= 0 && !self.getThePic) {
            [self.delegate CNChannelNewsControllerGetTheFirstPic:picNews.imageurls.firstObject[@"url"]];
            self.getThePic = YES;
        }
    }
}
-(void)setSwipeGes{
    UISwipeGestureRecognizer* leftSwipe = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(leftSwipe)];
    leftSwipe.direction = UISwipeGestureRecognizerDirectionLeft;
    [self.view addGestureRecognizer:leftSwipe];//左滑手势
    
    UISwipeGestureRecognizer* rightSwipe = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(rightSwipe)];
    rightSwipe.direction = UISwipeGestureRecognizerDirectionRight;
    [self.view addGestureRecognizer:rightSwipe];
    
    UISwipeGestureRecognizer* upSwipe = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(upSwipe)];
    upSwipe.direction = UISwipeGestureRecognizerDirectionUp;
    [self.view addGestureRecognizer:upSwipe];
}
-(void)upSwipe{
    [self  dismissViewControllerAnimated:YES completion:nil];
}
-(void)rightSwipe{
    self.index -= 6;
    if (self.index < 6) {
        self.index += 6;
        return;
    }
    CNChannelNews* theLastView = [self setChannelNews];
     __weak typeof(self) wVc = self;
    [UIView transitionFromView:self.channelNews toView:theLastView duration:3 options:UIViewAnimationOptionCurveEaseInOut | UIViewAnimationOptionTransitionFlipFromLeft completion:^(BOOL finished) {
        wVc.channelNews = theLastView;
    }];
}
-(void)leftSwipe{//左滑手势，翻页动作
   
   if (self.index >= self.situation.allNum.integerValue) {return;}
    self.index += 6;
    
    MYLog(@"%ld",self.index);
    __weak typeof(self) wVc = self;
    
    if (self.index >= 20 * self.situation.currentPage.intValue - (20 * self.situation.currentPage.integerValue%6)) {
        AFHTTPSessionManager* manager = [AFHTTPSessionManager manager];
        [manager.requestSerializer setValue:APPKey forHTTPHeaderField:@"apikey"];
        NSMutableDictionary* parameters = [NSMutableDictionary dictionary];
        parameters[@"channelId"] = self.channel.channelId;
        parameters[@"page"] = [NSString stringWithFormat:@"%ld",self.situation.currentPage.integerValue + 1];
        MBProgressHUD* hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.mode = MBProgressHUDModeIndeterminate;
        hud.removeFromSuperViewOnHide = YES;
        [manager GET:kUrlTheChannelSearchNews parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            [hud hide:YES];
            MYLog(@"%@",[NSThread currentThread]);
            NSArray* allNextNews = [CNManager parseTheNewsByDic:responseObject];
            [wVc.allNews addObjectsFromArray:allNextNews];
            [self    getTheChannelShowPic];
            CNNewsReadSituation* situa = [CNManager parseTheNewsReadSituationByDic:responseObject];
            wVc.situation = situa;
            [self trasformToNextView];
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            MYLog(@"%@",error.userInfo);
            [hud hide:YES];
            [MBProgressHUD showConnectFailed:wVc.view];
           }];
    }else{
        [self trasformToNextView];
    }
   }
-(void)trasformToNextView{
    __weak typeof(self) wVc = self;
    CNChannelNews* theNextView = [self setChannelNews];
   [UIView transitionFromView:self.channelNews toView:theNextView duration:2 options:UIViewAnimationOptionCurveEaseInOut | UIViewAnimationOptionTransitionFlipFromRight completion:^(BOOL finished) {
       wVc.channelNews = theNextView;
   }];

}
-(void)getTheDetailNews:(NSNotification*)notification{
    CNNews* news = notification.userInfo[@"news"];
    CNDetailNewsController* detailViewController = [[CNDetailNewsController alloc]init];
    detailViewController.news = news;
    [self presentViewController:detailViewController animated:YES completion:nil];
    MYLog(@"%@",news.title);
}
-(void)setInterChannelNameLabel{
    UILabel* channelName = [[UILabel alloc]init];
    channelName.text = self.channel.name;
    channelName.textColor = [UIColor cyanColor];
    channelName.shadowOffset = CGSizeMake(-1, -1);
    channelName.shadowColor = [UIColor blackColor];
    channelName.font = [UIFont italicSystemFontOfSize:17];
    [self.view addSubview:channelName];
    [channelName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(5);
        make.top.mas_equalTo(20);
        
    }];
    UIView* lineView = [[UIView alloc]init];
    lineView.backgroundColor = [UIColor orangeColor];
    [self.view addSubview:lineView];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(channelName);
        make.height.mas_equalTo(1);
        make.left.mas_equalTo(channelName.mas_right);
    }];
    UILabel* allNewsNumberlabel = [[UILabel alloc] init];
    allNewsNumberlabel.font = [UIFont systemFontOfSize:12];
    allNewsNumberlabel.textColor = [UIColor blackColor];
    allNewsNumberlabel.text = [self.situation.allNum stringValue];
    [self.view addSubview:allNewsNumberlabel];
    [allNewsNumberlabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(lineView);
        make.left.mas_equalTo(lineView.mas_right);
        make.right.mas_equalTo(-5);
    }];
}
//设置新闻的显示
-(CNChannelNews*)setChannelNews{
    NSRange range;
    if (self.index - 6 < self.allNews.count) {
        range.location = self.index - 6;
        if (self.allNews.count - self.index + 6 < 6) {
            range.length = self.allNews.count  - self.index + 6;
        }else{
        range.length = 6;
        }
    }
    NSArray* theNewsList = [self.allNews subarrayWithRange:range];
    CNChannelNews* allChannelNewsView = [CNChannelNews createTheChannelNewsView];
    allChannelNewsView.theNewsNumber = self.index;
    allChannelNewsView.theSelectedChannelNews = theNewsList;
    allChannelNewsView.frame = CGRectMake(0, 60, self.view.bounds.size.width,self.view.bounds.size.height - 60);
    return allChannelNewsView;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
