/**
* Copyright 2015 Kakao Corp.
*
* Redistribution and modification in source or binary forms are not permitted without specific prior written permission.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

/*!
 @header KOPushTokenInfo.h
 푸시 토큰의 정보를 담고 있는 구조체.
 */

#import <Foundation/Foundation.h>

/*!
 @class KOPushTokenInfo
 @discussion 푸시 토큰의 정보를 담고 있는 구조체.
 */
@interface KOPushTokenInfo : NSObject

/*!
 @property userId
 @abstract 해당 사용자의 아이디
 */
@property(nonatomic, readonly) NSString *userId;

/*!
 @property deviceId
 @abstract 해당 사용자의 등록된 디바이스 아이디
 */
@property(nonatomic, readonly) NSString *deviceId;

/*!
 @property pushType
 @abstract 푸시 토큰의 타입. "apns" 또는 "gcm"
 */
@property(nonatomic, readonly) NSString *pushType;

/*!
 @property pushToken
 @abstract 푸시 토큰
 */
@property(nonatomic, readonly) NSString *pushToken;

/*!
 @property createdAt
 @abstract 푸시 토큰의 생성 시간
 */
@property(nonatomic, readonly) NSString *createdAt;

/*!
 @property updatedAt
 @abstract 푸시 토큰의 수정된 시간
 */
@property(nonatomic, readonly) NSString *updatedAt;

- (id)initWithUserId:(NSString *)userId
            deviceId:(NSString *)deviceId
            pushType:(NSString *)pushType
           pushToken:(NSString *)pushToken
           createdAt:(NSString *)createdAt
           updatedAt:(NSString *)updatedAt;

@end
